#if defined(__linux__) || defined(__linux) || defined(linux) || defined(__gnu_linux__)
#include <cstddef>
#define __stdcall
#endif



#if defined (__GNUC__) && defined(__unix__)
  #define MYAPI __attribute__ ((__visibility__("default"))) 
#elif defined (WIN32)
  #define MYAPI __declspec(dllexport)
#endif


#ifdef __cplusplus
extern "C" {
#endif

MYAPI size_t getCurrentRSS();

MYAPI size_t getPeakRSS();

#ifdef __cplusplus
}
#endif

